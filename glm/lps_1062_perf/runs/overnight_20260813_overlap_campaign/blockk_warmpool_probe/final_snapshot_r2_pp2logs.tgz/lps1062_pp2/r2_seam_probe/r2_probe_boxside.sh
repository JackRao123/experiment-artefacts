#!/bin/bash
# R2 SEAM PROBE — box-side runner (R2_SEAM_PROBE.md). One node per invocation.
# Usage: r2_probe_boxside.sh <node_rank_label>   e.g.  r2_probe_boxside.sh rank0
# Isolated py-spy install (NEVER the trainer venv), attach to this node's target
# rank process, record 420s @ 250Hz with --threads, artifact to the shared FS.
# Non-blocking by design: run under nohup; completion line goes to the log.
set -uo pipefail

ROLE="${1:?usage: r2_probe_boxside.sh <rank0|rank8>}"
OUTDIR="${R2_OUTDIR:-/root/.cache/user_artifacts/lps1062_pp2/r2_seam_probe}"
mkdir -p "$OUTDIR"
LOG="$OUTDIR/probe_${ROLE}.log"
exec >"$LOG" 2>&1
echo "[$(date -Is)] R2 probe start: role=$ROLE host=$(hostname)"

# --- 1. isolated py-spy ---
PYSPY=""
if command -v py-spy >/dev/null 2>&1; then
  PYSPY="py-spy"
elif [ -x /tmp/r2spy/venv/bin/py-spy ]; then
  PYSPY="/tmp/r2spy/venv/bin/py-spy"
else
  echo "installing py-spy into /tmp/r2spy/venv (isolated; trainer venv untouched)"
  python3 -m venv /tmp/r2spy/venv && /tmp/r2spy/venv/bin/pip -q install py-spy
  PYSPY="/tmp/r2spy/venv/bin/py-spy"
fi
echo "py-spy: $($PYSPY --version 2>&1)"

# --- 2. find this node's target-rank trainer pid ---
# trainer ranks are `python -m trainers_server.dp_worker.main` procs with RANK=<n>
# in their env (inductor compile workers also carry RANK= — excluded by the
# cmdline filter; verified on wprm693 image).
TARGET_RANK=0; [ "$ROLE" = "rank8" ] && TARGET_RANK=8
PID=""
for p in $(pgrep -f 'trainers_server.dp_worker.main'); do
  if tr '\0' '\n' < /proc/$p/environ 2>/dev/null | grep -qx "RANK=$TARGET_RANK"; then
    PID=$p; break
  fi
done
if [ -z "$PID" ]; then
  # fallback: driver-provided pid file
  [ -f "$OUTDIR/${ROLE}.pid" ] && PID=$(cat "$OUTDIR/${ROLE}.pid")
fi
if [ -z "$PID" ]; then
  echo "STOP S1: could not identify rank $TARGET_RANK pid on this node — aborting, no improvisation"
  exit 1
fi
echo "target rank $TARGET_RANK pid=$PID: $(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null | head -c 200)"

# --- 3. record 420s @ 250Hz, threads on ---
OUT="$OUTDIR/r2_seam_${ROLE}.speedscope"
echo "[$(date -Is)] recording 420s @250Hz -> $OUT"
$PYSPY record -p "$PID" -r 250 -d 420 -f speedscope -o "$OUT" --threads
RC=$?
echo "[$(date -Is)] record exit rc=$RC size=$(stat -c %s "$OUT" 2>/dev/null || echo 0)"
[ $RC -eq 0 ] && [ -s "$OUT" ] && echo "PROBE_COMPLETE $OUT" || echo "PROBE_FAILED rc=$RC"
